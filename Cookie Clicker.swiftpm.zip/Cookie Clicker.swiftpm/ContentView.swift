import SwiftUI


struct GrowingButton: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 1.2 : 1)
            .animation(.easeOut(duration: 0.2), value: configuration.isPressed)
    }
}

struct ContentView: View {
    @State public var Cookies = 0
    @State public var CookiesPerSecond = 0
    @State public var Cursors = 0
    @State public var Grandmas = 0
    @State public var cookieFarms = 0
    @State var cursorCost = 10
    @State var grandmaCost = 100
    @State var cookieFarmCost = 1000
    @State var bakeryName = ""
    @State var highScoreBakery = ""
    let Running = true
    
    
    
    
    var body: some View {
        
        
        VStack {
            
            TextField("Enter bakery name here", text: $bakeryName)
            
            Text("Cookies: \(Cookies)")
                .font(.custom("", size: 60))
            Text("Cookies Per Second: \(CookiesPerSecond)")
                .font(.custom("", size: 25))
            
            Button{
                
                //print("+1")
                Cookies += 1
                print(Cookies)
            } label: {
                Image("cookie")
                    .resizable()
                    .frame(width: 300, height: 300)
            }
            .buttonStyle(GrowingButton())
            
            ScrollView {
                LazyVStack{
                    Button{
                        print("button 2 tapped")
                        if Cookies >= cursorCost {
                            Cookies -= cursorCost
                            Cursors += 1
                            cursorCost = Int(Double(cursorCost) * 1.25)
                            CookiesPerSecond = Cursors + Grandmas * 5
                        }
                        
                    } label: {
                        ZStack{
                            RoundedRectangle(cornerRadius: 10)
                                .frame(maxWidth: .infinity, maxHeight: 75, alignment: .center)
                                .foregroundColor(.white)
                            VStack{
                                Text("Cursors: \(Cursors)")
                                    .foregroundColor(.black)
                                Text("Cursor Cost: \(cursorCost)")
                                    .foregroundColor(.black)
                            }
                        }
                    Button{
                        print("button 2 tapped")
                        if Cookies >= cursorCost {
                            Cookies -= cursorCost
                            Cursors += 1
                            cursorCost = Int(Double(cursorCost) * 1.25)
                            CookiesPerSecond = Cursors + Grandmas * 5
                        }
                        
                    } label: {
                        ZStack{
                            RoundedRectangle(cornerRadius: 10)
                                .frame(maxWidth: .infinity, maxHeight: 75, alignment: .center)
                                .foregroundColor(.white)
                            VStack{
                                Text("Cursors: \(Cursors)")
                                    .foregroundColor(.black)
                                Text("Cursor Cost: \(cursorCost)")
                                    .foregroundColor(.black)
                            }
                        }
                        .buttonStyle(GrowingButton())
                        
                        Button{
                            print("button 3 tapped")
                            if Cookies >= grandmaCost {
                                Cookies -= grandmaCost
                                Grandmas += 1
                                grandmaCost = Int(Double(grandmaCost) * 1.25)
                                CookiesPerSecond = Cursors + Grandmas * 5
                            }
                            
                        } label: {
                            ZStack{
                                RoundedRectangle(cornerRadius: 10)
                                    .frame(maxWidth: .infinity, maxHeight: 75, alignment: .center)
                                    .foregroundColor(.white)
                                VStack{
                                    Text("Grandmas: \(Grandmas)")
                                        .foregroundColor(.black)
                                    Text("Grandma Cost: \(grandmaCost)")
                                        .foregroundColor(.black)
                                }
                                
                            }
                            .buttonStyle(GrowingButton())
                            
                            Button{
                                print("button 4 tapped")
                                if Cookies >= cookieFarmCost {
                                    Cookies -= cookieFarmCost
                                    cookieFarms += 1
                                    cookieFarmCost = Int(Double(cookieFarmCost) * 1.25)
                                    CookiesPerSecond = Cursors + Grandmas * 5
                                }
                                
                            } label: {
                                ZStack{
                                    RoundedRectangle(cornerRadius: 10)
                                        .frame(maxWidth: .infinity, maxHeight: 75, alignment: .center)
                                        .foregroundColor(.white)
                                    VStack{
                                        Text("Cookie Farms: \(cookieFarms)")
                                            .foregroundColor(.black)
                                        Text("Cookie Farm Cost: \(cookieFarmCost)")
                                            .foregroundColor(.black)
                                    }
                                    
                                }
                                .buttonStyle(GrowingButton())
                                
                            }
                            
                            
                            
                        }
                        .onAppear(perform: {
                            Loop()
                        })
                        
                        
                    }
                }
                
            }
        }
        
    }
    
    func Loop() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            CookiesPerSecond = Cursors + Grandmas * 5
            Cookies += Cursors
            Cookies += Grandmas * 5 + cookieFarms * 10
            Loop()
        }
    }
}

